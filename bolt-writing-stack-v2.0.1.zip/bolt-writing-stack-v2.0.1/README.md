# Bolt.new writing stack, v2

The content and copywriting skills for Bolt.new and StackBlitz. **Internal use only.** Don't share outside StackBlitz.

- **Version:** 2.0.1
- **Snapshot taken:** September 22, 2026
- **Source of truth:** `trajanodoce/bolt-writing-plugins` (private). This zip is a point-in-time copy and will not auto-update.

## Install from the marketplace if you can

The marketplace keeps you current. This zip goes stale the next time anything changes.

```
/plugin marketplace add trajanodoce/bolt-writing-plugins
/plugin install write-strike-kit@bolt-writing-plugins
/plugin install mr-gay@bolt-writing-plugins
```

Needs collaborator access on the private repo. Ask Taylor.

**From this zip instead:** unzip, copy the folders into `~/.claude/skills/`, restart Claude Code. The skills reference each other by `~/.claude/skills/<name>/`, so keep the folder names.

## What v2 is

v1 was a good set of skills that had grown unevenly. v2 is the same material reorganized around one idea: **craft comes first, and everything else serves it.**

**The promise is step one, at every depth.** Before routing, before research, before a word: who is this for, what is it for (AEO/GEO, awareness, consideration, or decision), and why should they give a shit. If the last one has no answer, the piece has no thesis and nothing downstream will supply one. Quick jobs answer all three too.

**Craft precedes voice.** `write-strike/references/prose-craft.md` is the first thing to read, because it's the first thing used. Its eight passes are listed in the draft step itself, not just linked: the promise, the lead, sentence engineering, concreteness, the music, the thread, the ending, the 10% cut. Tone of voice comes after, governing how well-built prose sounds as Bolt.new.

**The tells are drafting constraints, not an audit.** `stops-slop`'s rulebook is pass 0. You read the banned list, the tiered vocabulary, and the structural tells *before* the first sentence. A tell that survives to the edit step is a drafting failure, not a cleanup task. The reasoning: a tell sanded out of a finished sentence leaves a sentence that was built around the tell.

**The outline is built with the craft.** Sections are one move each (state a claim, prove a claim, turn the argument), joined with *but* or *therefore* rather than *and then*, each naming the specific it will carry. A section that doesn't serve the promise dies at the outline, before it costs a draft.

**Editing is a menu of separate tools**, applied to a draft that already exists. `stops-slop` first and always, then whichever the piece needs: the **Ogilvy pass** for persuasion (default on customer stories, sales enablement, web copy, ads), **mr-gay** for the copyedit, **aeo-craft** for citability on anything bound for bolt.new, and a **Schwartz re-angle** when the substance is right and the opening isn't.

### 2.0.1

One fix. The rename collapsed two tools that used to be distinct (a generic `stop-slop` for any copy, `bolt-stop-slop` for Bolt.new content) into a single name, which left mr-gay's slop handoff reading "bounce it to stops-slop for general copy, stops-slop for Bolt.new content": the same tool named twice. There is one slop skill now, so the two-tool distinction went with it.

## The pipeline

```
route → the promise (who / what for / why they care)
      → maybe research, maybe an outline (built with the craft)
      → draft: pass 0 know the tells, then passes 1-8, then voice, then GEO
      → edit: stops-slop (mandatory) → Ogilvy / mr-gay / aeo-craft / Schwartz
```

## What's in here

| Skill | What it does |
|---|---|
| `write-strike` | The orchestrator. Routes by content type, runs the promise, then craft, then the edit menu. Start here. |
| `bolt-blog` | Blog posts. Its own brief, optimize, and outrank workflows. |
| `bolt-content-formats` | Structural templates: customer stories, webinars, sales enablement, creator briefs, Minto scaffold. |
| `ogilvy-copywriting` | The persuasion edit. Diagnostic questions asked of a finished draft. |
| `bolt-TOV-and-guidelines` | Brand voice, editorial rules, citation format. Applies to everything. |
| `bolter-tones` | Per-person voice profiles for ghostwriting social. |
| `bolt-icp` | Four ICPs, stack-ranked, plus three named personas. Readability and jargon calibration. |
| `stops-slop` | The AI-tells filter and the 35/50 gate. Its rules are drafting constraints. |
| `mr-gay` | The copyedit: diagnostic lenses, readability scoring, repetition scan, numbered findings. |
| `aeo-craft` | The citability sculpt for bolt.new-bound work. Nine passes, measured against Cairrot. |
| `bolt-seo-geo` | Live GA4 and Search Console for bolt.new. Needs your own Google credentials. |

## Two rules worth knowing before you write

**Citations in web copy are two-part.** Hyperlink the phrase that carries the statistic, not the publisher's name, then close the sentence with a plain-text `(Publisher, date)`:

> Software spend per employee [rose 27% in 2025](url) (Zylo, 2026).

The anchor text describes the claim, which a bare brand name never does. The plain parenthetical survives an AI engine lifting the passage and stripping the markup. Long-form (ebooks, whitepapers, guides, reports) keeps Chicago superscript plus a Works Cited appendix.

**Audiences are ranked.** ICP 1 business owner or entrepreneur, ICP 2 PM or product designer, ICP 3 in-house marketer, ICP 4 agency or creative freelancer. Then three unranked personas: enterprise CTO, enterprise CPO, professional developer. There is no general reader: a broad piece is for ICP 1, written accessibly.

## Not in this zip

Skills carrying live API keys or customer data stay on Taylor's machine: `bolt-cairrot`, `bolt-sybill`, `bolt-story-pipeline`, `the-stacks`, `the-full-atwood`, `front-desk`. If you need AI-visibility numbers or sales-call material, ask her rather than installing anything.
