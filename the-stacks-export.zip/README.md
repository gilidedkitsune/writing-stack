# The Stacks — research assistant skill

A research skill with newsroom-level sourcing discipline: nothing gets delivered
that can't be traced to its origin, everything carries a date, and known-bad
stats are blocked by a trap list.

## Install

Drop the `the-stacks` folder into your skills directory:

    ~/.claude/skills/the-stacks/

Then ask for research the way you'd ask a person: "research X", "find stats for
this piece", "what's the competitive landscape", "who covers this topic".

## Before first use: fill in five placeholders

This is the portable version, so the pointers to your own material are blank.
Open `SKILL.md` and replace each bracket with wherever that lives for you (a
Notion page, a Google Doc, a folder, a URL — it doesn't matter, as long as the
assistant can reach it).

| Placeholder | What to put there |
|---|---|
| `[VERIFIED SOURCE LIBRARY]` | Where you keep stats you've already traced to origin |
| `[TRAP LIST LOCATION]` | Your Do Not Cite list of known-bad stats (can live inside the library) |
| `[RESEARCH HUB]` | Where finished research reports get filed |
| `[YOUR COMPETITIVE SET]` | The companies to track by default for market intel |
| `[YOUR DOCS LOCATION]` | Where exported documents should be saved |

Starting from nothing is fine. Create two empty pages — a source library and a
research hub — and let them fill up; the skill offers to deposit verified finds
and newly discovered traps every time it runs, so the libraries compound.

## What makes it different from just searching

- **Origin, not middleman.** The analyst report itself, never the news article
  quoting it.
- **Independence rule.** Three articles citing the same study count as one
  source, not three.
- **Confidence tiers** on every load-bearing finding, and disagreements between
  sources get shown rather than silently resolved.
- **Mandatory counter-review.** It attacks its own findings before delivering and
  names the weaknesses, because a brief with no stated limitations hasn't been
  reviewed.
- **Stat cards** with pre-written citations, so research drops straight into a
  draft without a second lookup.

## Pairs well with

A `deep-research` skill for the heavy fan-out work (The Stacks post-processes
its output through the sourcing bar), and whatever drafting and editing skills
you already use.
